# skill-chat-client
Skillbox android chat client
